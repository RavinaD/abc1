package cs.com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cs.com.DaoImpl.AdminDaoImpl;
import cs.com.DaoImpl.CustomerDaoImpl;
import cs.com.daos.AdminDAO;
import cs.com.daos.CustomerDAO;
import cs.com.models.Administrator;
import cs.com.models.Customer;

public class ChangePasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CustomerDAO cd=new CustomerDaoImpl();
	AdminDAO ad=new AdminDaoImpl();

	public void init(ServletConfig config) throws ServletException {
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		Customer cust=(Customer)session.getAttribute("Cust");
		Administrator admin=(Administrator)session.getAttribute("Admin");
		
		String password=request.getParameter("password");
		String newpassword=request.getParameter("newpassword");
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		if(admin==null){
			
			RequestDispatcher rd=request.getRequestDispatcher("/passwordchange.jsp");
			RequestDispatcher rd1=request.getRequestDispatcher("/login.jsp");
			cust.setPassword(password);
			boolean a=cd.validateCustomer(cust);
			
			if(a){
				if(cd.passwordUpdate(cust.getUserName(), newpassword)){
					out.println("<h3><b><i>Password has been changed. Login with new password</i></b></h3>");
					rd1.include(request, response);
				}
				else
				{
					out.println("<h3><b><i>Error in Updation, please try again</i></b></h3>");
					rd.include(request, response);
				}
			}
			else{
				out.println("<h3><b><i>Current Password entered is incorrect</i></b></h3>");
				rd.include(request, response);
			}
		}
		else if(cust==null)
		{
			RequestDispatcher rd=request.getRequestDispatcher("/passwordchange.jsp");
			RequestDispatcher rd1=request.getRequestDispatcher("/login.jsp");
			admin.setPassword(password);
			boolean a=ad.validateAdmin(admin);
			
			if(a){
				if(ad.passwordUpdate(admin.getUserName(), newpassword)){
					out.println("<h3><b><i>Password has been changed. Login with new password</i></b></h3>");
					rd1.include(request, response);
				}
				else
				{
					out.println("<h3><b><i>Error in Updation, please try again</i></b></h3>");
					rd.include(request, response);
				}
			}
			else{
				out.println("<h3><b><i>Current Password entered is incorrect</i></b></h3>");
				rd.include(request, response);
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
