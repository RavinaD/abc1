package com.techM.shareChacha.controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techM.shareChacha.MoreSharesException;
import com.techM.shareChachaBeans.Company;
import com.techM.shareChachaBeans.User;
import com.techM.shareChachaBeans.UserStock;
import com.techM.shareChachaDB.UserDB;

/**
 * Servlet implementation class SellStocksServlet
 */
public class SellStocksServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SellStocksServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession(false);
		
		try {
		ArrayList<Company> alist=new ArrayList<Company>();
				
		User u = (User) session.getAttribute("userObj");
		Company comp = (Company) session.getAttribute("company4");
		
	
		
		int shares = 0;
		shares = Integer.parseInt(request.getParameter("noOfShares"));
			
		UserDB uDB = new UserDB();
		
		int i = 0;
		
		try{
			i = uDB.updateUserStocks2(comp, u, shares);	
			
			if( i == -5 )
				throw new MoreSharesException("You don't have enough shares to sell");
		} catch( MoreSharesException me ) {
			boolean sts = uDB.moreSharesExc( u, "You don't have enough shares to sell" );
			if( sts ) {
				session.setAttribute("status4","You don't have enough shares to sell");
		    	RequestDispatcher rd=request.getRequestDispatcher("SellPageServlet");
		    	rd.include(request,response);
			}
	    	
		}
	
		i = i + uDB.updateStocks2(comp, u, shares);
	
		if( i == 2 ) {
			session.setAttribute("status4","Sell successful");
					
			ArrayList<UserStock> alist2=new ArrayList<UserStock>();
			
			alist2 = uDB.sellStocks( u );
			
			u.setUsrStk(alist2);
			
			session.setAttribute("userObj", u);
			
			RequestDispatcher rd=request.getRequestDispatcher("SellPageServlet");
	    	rd.forward(request,response);
	    }
	    else {
	    	throw new Exception();
	    }
		} catch ( Exception ee ) {
			session.setAttribute("status4", "Error while selling. Please try again..");
	    	RequestDispatcher rd=request.getRequestDispatcher("SellPageServlet");
	    	rd.forward(request,response);
	    }
	}



	}


